'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var app = document.getElementById('app');
var _ReactDOM = ReactDOM;
var render = _ReactDOM.render;
var _React = React;
var Component = _React.Component;

var App = function (_Component) {
  _inherits(App, _Component);

  function App(props) {
    _classCallCheck(this, App);

    var _this = _possibleConstructorReturn(this, _Component.call(this, props));

    _this.state = {
      todos: [],
      lastId: 0,
      viewableTodos: [],
      activeFilter: 'all'
    };
    _this.addToDo = _this.addToDo.bind(_this);
    _this.deleteToDo = _this.deleteToDo.bind(_this);
    _this.toggleToDo = _this.toggleToDo.bind(_this);
    _this.mapToFilter = _this.mapToFilter.bind(_this);
    _this.switchFilter = _this.switchFilter.bind(_this);
    return _this;
  }

  App.prototype.addToDo = function addToDo(value) {
    var toAdd = {
      text: value,
      completed: false,
      id: ++this.state.lastId
    };
    var todos = [].concat(this.state.todos, [toAdd]);
    this.setState({
      todos: todos,
      lastId: toAdd.id,
      viewableTodos: this.mapToFilter(todos, this.state.activeFilter)
    });
  };

  App.prototype.deleteToDo = function deleteToDo(id) {
    var todos = this.state.todos.filter(function (elem) {
      return elem.id !== id;
    });
    this.setState({
      todos: todos,
      viewableTodos: this.mapToFilter(todos, this.state.activeFilter)
    });
  };

  App.prototype.toggleToDo = function toggleToDo(id) {
    var todos = this.state.todos.map(function (elem) {
      if (elem.id === id) elem.completed = !elem.completed;
      return elem;
    });
    this.setState({
      todos: todos,
      viewableTodos: this.mapToFilter(todos, this.state.activeFilter)
    });
  };

  App.prototype.mapToFilter = function mapToFilter(todos, filter) {
    var map = {
      all: function all() {
        return true;
      },
      completed: function completed(elem) {
        return elem.completed === true;
      },
      active: function active(elem) {
        return elem.completed === false;
      }
    };
    return todos.filter(map[filter]);
  };

  App.prototype.switchFilter = function switchFilter(filter) {
    this.setState({
      activeFilter: filter,
      viewableTodos: this.mapToFilter(this.state.todos, filter)
    });
  };

  App.prototype.render = function render() {
    var _this2 = this;

    return React.createElement(
      'div',
      { className: this.state.todos.length > 0 ? 'container moved' : 'container' },
      React.createElement(AddToDo, { add: function add(value) {
          _this2.addToDo(value);
        } }),
      React.createElement(Filters, {
        active: this.state.activeFilter,
        dispatch: function dispatch(_dispatch) {
          _this2.switchFilter(_dispatch);
        }
      }),
      React.createElement(
        'ul',
        { className: 'toDoList' },
        React.createElement(
          FlipMove,
          {
            leaveAnimation: 'elevator',
            enterAnimation: 'accordianVertical'
          },
          this.state.viewableTodos.map(function (elem, index) {
            return React.createElement(
              'li',
              { key: elem.id },
              React.createElement(ToDo, _extends({}, elem, {
                'delete': function _delete(id) {
                  _this2.deleteToDo(id);
                },
                toggle: function toggle(id) {
                  _this2.toggleToDo(id);
                }
              }))
            );
          })
        )
      )
    );
  };

  return App;
}(Component);

var AddToDo = function (_Component2) {
  _inherits(AddToDo, _Component2);

  function AddToDo(props) {
    _classCallCheck(this, AddToDo);

    var _this3 = _possibleConstructorReturn(this, _Component2.call(this, props));

    _this3.state = {
      value: ''
    };
    _this3.sendUp = _this3.sendUp.bind(_this3);
    return _this3;
  }

  AddToDo.prototype.sendUp = function sendUp(value) {
    this.props.add(value);
    this.setState({ value: '' });
  };

  AddToDo.prototype.render = function render() {
    var _this4 = this;

    return React.createElement(
      'div',
      { className: 'insertToDos' },
      React.createElement('input', { type: 'text',
        placeholder: 'Insert to-do',
        value: this.state.value,
        onChange: function onChange(event) {
          _this4.setState({ value: event.target.value });
        },
        onKeyUp: function onKeyUp(event) {
          if (event.keyCode === 13) _this4.sendUp(_this4.state.value);
        } }),
      React.createElement(
        'button',
        { onClick: function onClick(event) {
            _this4.sendUp(_this4.state.value);
          } },
        'Add'
      )
    );
  };

  return AddToDo;
}(Component);

var ToDo = function ToDo(props) {
  return React.createElement(
    'div',
    { className: 'singleToDo' },
    React.createElement(
      'button',
      { onClick: function onClick() {
          props.delete(props.id);
        } },
      '×'
    ),
    React.createElement(
      'span',
      { className: props.completed ? 'completed' : '' },
      props.text
    ),
    React.createElement(
      'span',
      {
        onClick: function onClick() {
          props.toggle(props.id);
        } },
      props.completed ? '🔘' : '⚪️'
    )
  );
};

var Filters = function (_Component3) {
  _inherits(Filters, _Component3);

  function Filters(props) {
    _classCallCheck(this, Filters);

    var _this5 = _possibleConstructorReturn(this, _Component3.call(this, props));

    _this5.state = {
      filters: ['all', 'completed', 'active']
    };
    return _this5;
  }

  Filters.prototype.render = function render() {
    var _this6 = this;

    return React.createElement(
      'div',
      { className: 'filters' },
      this.state.filters.map(function (elem) {
        return React.createElement(
          'div',
          {
            onClick: function onClick() {
              _this6.props.dispatch(elem);
            },
            className: _this6.props.active === elem ? 'active' : ''
          },
          elem
        );
      })
    );
  };

  return Filters;
}(Component);

render(React.createElement(App, null), app);